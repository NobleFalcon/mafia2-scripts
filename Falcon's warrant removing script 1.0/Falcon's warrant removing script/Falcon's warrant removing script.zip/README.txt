*This script require mafiainjector to be used.*

How to install?
- Rename the script to "F1" - "F12"
- Run mafiainjector
- Press the [F1-F12] key you named the file to run the script.


Features:
- Remove warrant from owned cars.
- Prevent police from putting a warrant on you. [Contains known bug, read [BUG 0001].]
- Prevent police from arresting you.

Known bugs:
[BUG 0001] If you shoot at officers, they might put a warrant on you.
[FIX 0001] Run the script again and it will be removed.