*This script require mafiainjector to be used.*

How to install?
- Rename the script to "F1" - "F12"
- Run mafiainjector
- Press the [F1-F12] key you named the file to run the script.


Features:
- Tune car to whatever level you want.

Known bugs
- None